<?php
/**
 * Template Parts - Header - Utility
 * 
 * Header Masthead
 * 
 * @package mingo
 */

?>

<?php wp_utility_menu(); ?>
